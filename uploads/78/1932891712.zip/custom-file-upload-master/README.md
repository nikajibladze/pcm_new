# custom-file-upload
How to create the Custom File Upload using HTML and CSS
